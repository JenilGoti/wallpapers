import 'dart:ui';

import 'package:flutter/material.dart';

class ThemeSettingScreen extends StatefulWidget {
  const ThemeSettingScreen(
      {Key? key, required this.themeData, required this.setTheme})
      : super(key: key);
  static const routName = '/theme-setting-screen';

  final Map<String, Object> themeData;
  final Function setTheme;

  @override
  State<ThemeSettingScreen> createState() => _ThemeSettingScreenState();
}

class _ThemeSettingScreenState extends State<ThemeSettingScreen> {
  Map<String, Object>? _newTheme;
  bool? _themeSwitch;
  MaterialColor? _selectedPrimaryColor;
  MaterialAccentColor? _selectedAccentCollor;
  List<Map<String, Object>> _PrimaryColor = [
    {
      'name': 'Indigo',
      'value': Colors.indigo,
    },
    {
      'name': 'Lime',
      'value': Colors.lime,
    },
    {
      'name': 'Orange',
      'value': Colors.orange,
    },
    {
      'name': 'Pink',
      'value': Colors.pink,
    },
    {
      'name': 'purple',
      'value': Colors.purple,
    },
    {
      'name': 'red',
      'value': Colors.red,
    },
    {
      'name': 'teal',
      'value': Colors.teal,
    },
  ];
  List<Map<String, Object>> _accentColor = [
    {
      'name': 'Indigo accent',
      'value': Colors.indigoAccent,
    },
    {
      'name': 'Lime accent',
      'value': Colors.limeAccent,
    },
    {
      'name': 'Orange accent',
      'value': Colors.orangeAccent,
    },
    {
      'name': 'Pink accent',
      'value': Colors.pinkAccent,
    },
    {
      'name': 'purple accent',
      'value': Colors.purpleAccent,
    },
    {
      'name': 'red accent',
      'value': Colors.redAccent,
    },
    {
      'name': 'teal accent',
      'value': Colors.tealAccent,
    },
  ];
  

  @override
  void initState() {
    _newTheme = widget.themeData;
    _themeSwitch = _newTheme!['brightness'] == Brightness.dark;
    _selectedPrimaryColor = _newTheme!['primarySwatch'] as MaterialColor;
    _selectedAccentCollor = _newTheme!['accentColor'] as MaterialAccentColor;
    super.initState();
  }
  

  @override
  Widget build(BuildContext context) {
    _setTheme() {
      if (_themeSwitch!) {
        _newTheme!['brightness'] = Brightness.dark;
      } else {
        _newTheme!['brightness'] = Brightness.light;
      }
      _newTheme!['primarySwatch']=_selectedPrimaryColor as Object;
      _newTheme!['accentColor']=_selectedAccentCollor as MaterialAccentColor;

      widget.setTheme(_newTheme);
      Navigator.pop(context);
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Them Settings'),
        actions: [
          IconButton(
            icon: Icon(Icons.save),
            onPressed: () {
              _setTheme();
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          children: [
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(child: Text('theme mode')),
                  Expanded(
                    child: Container(
                      alignment: Alignment.centerLeft,
                      child: Switch(
                          value: _themeSwitch!,
                          onChanged: (value) {
                            setState(() {
                              _themeSwitch = value;
                            });
                          }),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              children: [
                Expanded(child: Text('Select Primary color')),
                Expanded(
                  child: Container(
                    alignment: Alignment.centerLeft,
                    child: DropdownButton(
                      elevation: 10,
                      value: _selectedPrimaryColor,
                      items: [
                        ..._PrimaryColor.map((e) {
                          return DropdownMenuItem(
                            value: e['value'],
                            child: Text(e['name'] as String),
                          );
                        })
                      ],
                      onChanged: (Object? value) {
                        setState(() {
                          _selectedPrimaryColor = value as MaterialColor?;
                        });
                      },
                    ),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Expanded(child: Text('Select Accent color')),
                Expanded(


                  child: Container(
                    alignment: Alignment.centerLeft,
                    child: DropdownButton(
                      elevation: 10,
                      value: _selectedAccentCollor,
                      items: [
                        ..._accentColor.map((e) {
                          return DropdownMenuItem(
                            value: e['value'],
                            child: Text(e['name'] as String),
                          );
                        })
                      ],
                      onChanged: (Object? value) {
                        setState(() {
                          _selectedAccentCollor = value as MaterialAccentColor?;
                        });
                      },
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
