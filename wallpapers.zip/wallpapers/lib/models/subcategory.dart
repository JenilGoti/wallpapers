class SubCategory {
  final String id;
  final String name;
  final String imgUrl;
  final String Categoryes;

  const SubCategory({
    required this.Categoryes,
    required this.id,
    required this.name,
    required this.imgUrl,
  });
}
