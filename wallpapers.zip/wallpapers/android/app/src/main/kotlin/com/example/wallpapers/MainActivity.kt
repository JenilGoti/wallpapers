package com.example.wallpapers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
